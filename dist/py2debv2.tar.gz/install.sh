#!/bin/bash
sudo dpkg -i py2debv2.deb
